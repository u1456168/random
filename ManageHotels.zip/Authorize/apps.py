from django.apps import AppConfig


class AuthorizeConfig(AppConfig):
    name = 'Authorize'
