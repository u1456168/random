from django.apps import AppConfig


class ManagehotelsConfig(AppConfig):
    name = 'ManageHotels'
