from django.contrib import admin
from ManageHotels.models import Photo

# Register your models here.
admin.site.register(Photo)
