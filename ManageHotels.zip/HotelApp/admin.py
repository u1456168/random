from django.contrib import admin
from HotelApp.models import Hotels
from HotelApp.models import Review


admin.site.register(Hotels)
admin.site.register(Review)
